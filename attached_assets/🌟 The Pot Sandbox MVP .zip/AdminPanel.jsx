
// AdminPanel.jsx - Dev tools to simulate app states

import React, { useState } from 'react';
import theme from '../styles/theme';

const AdminPanel = ({ onErrorToggle, onRoleChange }) => {
  const [errorState, setErrorState] = useState(false);
  const [role, setRole] = useState("member");

  const toggleError = () => {
    const newState = !errorState;
    setErrorState(newState);
    onErrorToggle(newState);
  };

  const changeRole = (e) => {
    const newRole = e.target.value;
    setRole(newRole);
    onRoleChange(newRole);
  };

  return (
    <div style={{ backgroundColor: theme.colors.secondaryBackground, padding: '1rem', color: theme.colors.secondaryText }}>
      <h3 style={{ color: theme.colors.primaryText }}>Admin Panel</h3>
      <p>Developer tools for testing sandbox states</p>

      <button onClick={toggleError} style={{ marginBottom: '1rem' }}>
        Toggle Error Simulation: {errorState ? "ON" : "OFF"}
      </button><br />

      <label>Simulate User Role: </label>
      <select value={role} onChange={changeRole}>
        <option value="admin">Admin</option>
        <option value="member">Member</option>
        <option value="voter">Voter</option>
      </select>
    </div>
  );
};

export default AdminPanel;
