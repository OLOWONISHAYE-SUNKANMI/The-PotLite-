
// App.js - Root application for The Pot MVP

import React, { useState } from 'react';
import CreatePot from './pages/CreatePot';
import PotDashboard from './pages/PotDashboard';
import theme from './styles/theme';

const App = () => {
  const [pot, setPot] = useState(null);

  return (
    <div style={{ fontFamily: theme.font.family, padding: '2rem', backgroundColor: theme.colors.primaryBackground }}>
      {!pot ? (
        <CreatePot onCreate={(newPot) => setPot(newPot)} />
      ) : (
        <PotDashboard pot={pot} />
      )}
    </div>
  );
};

export default App;
