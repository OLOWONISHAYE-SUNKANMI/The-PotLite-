
// AppRoutes.js - Navigation routing between main pages

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import CreatePot from './pages/CreatePot';
import PotDashboard from './pages/PotDashboard';
import FeedbackForm from './pages/FeedbackForm';
import AdminPanel from './components/AdminPanel';
import TransactionLog from './components/TransactionLog';

const AppRoutes = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<CreatePot />} />
        <Route path="/dashboard" element={<PotDashboard />} />
        <Route path="/transactions" element={<TransactionLog logs={[]} />} />
        <Route path="/feedback" element={<FeedbackForm />} />
        <Route path="/admin" element={<AdminPanel />} />
      </Routes>
    </Router>
  );
};

export default AppRoutes;
