
// CreatePot.jsx - Pot creation form for sandbox MVP

import React, { useState } from 'react';
import theme from '../styles/theme';

const CreatePot = () => {
  const [potName, setPotName] = useState('');
  const [goalAmount, setGoalAmount] = useState('');
  const [payoutMethod, setPayoutMethod] = useState('');
  const [withdrawalMethod, setWithdrawalMethod] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Pot Created:", { potName, goalAmount, payoutMethod, withdrawalMethod });
    // Integrate with dummy backend or context here
  };

  return (
    <div style={{ backgroundColor: theme.colors.primaryBackground, color: theme.colors.secondaryText, padding: '2rem', borderRadius: '8px' }}>
      <h2 style={{ color: theme.colors.primaryText }}>Create a New Pot</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Pot Name</label><br />
          <input type="text" value={potName} onChange={(e) => setPotName(e.target.value)} required />
        </div>
        <div>
          <label>Goal Amount</label><br />
          <input type="number" value={goalAmount} onChange={(e) => setGoalAmount(e.target.value)} required />
        </div>
        <div>
          <label>Payout Structure</label><br />
          <select value={payoutMethod} onChange={(e) => setPayoutMethod(e.target.value)} required>
            <option value="">Select...</option>
            <option value="one-to-many">One-to-Many (One deposits, all receive)</option>
            <option value="many-to-one">Many-to-One (All deposit, one receives)</option>
            <option value="many-to-selected">Many-to-Selected (All deposit, selected receive)</option>
          </select>
        </div>
        <div>
          <label>Withdrawal Method</label><br />
          <select value={withdrawalMethod} onChange={(e) => setWithdrawalMethod(e.target.value)} required>
            <option value="">Select...</option>
            <option value="vote">Democratic Vote</option>
            <option value="admin">Admin Approval</option>
            <option value="timed">Timed Release</option>
          </select>
        </div>
        <br />
        <button type="submit" style={{
          background: `linear-gradient(to right, ${theme.colors.buttonGradientStart}, ${theme.colors.buttonGradientEnd})`,
          color: 'white',
          padding: '0.5rem 1rem',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer'
        }}>
          Start Pot
        </button>
      </form>
    </div>
  );
};

export default CreatePot;
