
// DepositSim.jsx - Simulate deposits in sandbox mode

import React, { useState } from 'react';
import theme from '../styles/theme';

const DepositSim = ({ pot, onDeposit }) => {
  const [amount, setAmount] = useState(0);

  const handleDeposit = () => {
    if (amount > 0) {
      onDeposit(amount);
    }
  };

  return (
    <div style={{ marginTop: '1rem', backgroundColor: theme.colors.primaryBackground, padding: '1rem', borderRadius: '8px', color: theme.colors.secondaryText }}>
      <h3>Simulate Deposit</h3>
      <p>Deposit coins into: <strong>{pot.name}</strong></p>
      <input
        type="number"
        value={amount}
        onChange={(e) => setAmount(Number(e.target.value))}
        placeholder="Enter amount"
      />
      <button
        onClick={handleDeposit}
        style={{
          background: `linear-gradient(to right, ${theme.colors.buttonGradientStart}, ${theme.colors.buttonGradientEnd})`,
          color: 'white',
          padding: '0.5rem 1rem',
          marginLeft: '1rem',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer'
        }}
      >
        Deposit
      </button>
    </div>
  );
};

export default DepositSim;
