
// DummyUserContext.js - Holds the mock user for testing

import React, { createContext, useContext } from 'react';

const DummyUserContext = createContext({ name: "Alice" });

export const useUser = () => useContext(DummyUserContext);

export const DummyUserProvider = ({ children }) => {
  const user = { name: "Alice", email: "alice@example.com" }; // Simulated user

  return (
    <DummyUserContext.Provider value={user}>
      {children}
    </DummyUserContext.Provider>
  );
};
