
// FeedbackForm.jsx - Simple in-app tester feedback form

import React, { useState } from 'react';
import theme from '../styles/theme';

const FeedbackForm = () => {
  const [responses, setResponses] = useState({ q1: '', q2: '', q3: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setResponses(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Feedback submitted:", responses);
    alert("Thanks for your feedback!");
  };

  return (
    <div style={{ padding: '1rem', backgroundColor: theme.colors.secondaryBackground, color: theme.colors.secondaryText }}>
      <h3 style={{ color: theme.colors.primaryText }}>We’d love your feedback!</h3>
      <form onSubmit={handleSubmit}>
        <label>1. Was it easy to use?</label><br />
        <input type="text" name="q1" value={responses.q1} onChange={handleChange} /><br />

        <label>2. Which method felt most fair?</label><br />
        <input type="text" name="q2" value={responses.q2} onChange={handleChange} /><br />

        <label>3. Would you trust using this with real money?</label><br />
        <input type="text" name="q3" value={responses.q3} onChange={handleChange} /><br /><br />

        <button type="submit" style={{
          background: `linear-gradient(to right, ${theme.colors.buttonGradientStart}, ${theme.colors.buttonGradientEnd})`,
          color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '4px'
        }}>
          Submit Feedback
        </button>
      </form>
    </div>
  );
};

export default FeedbackForm;
