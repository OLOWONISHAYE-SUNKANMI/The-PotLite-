
// PotContext.js - Global context for managing Pot state

import React, { createContext, useContext, useState } from 'react';

const PotContext = createContext();

export const usePot = () => useContext(PotContext);

export const PotProvider = ({ children }) => {
  const [currentPot, setCurrentPot] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [voteStatus, setVoteStatus] = useState({});
  const [deposits, setDeposits] = useState([]);

  const addTransaction = (tx) => setTransactions((prev) => [...prev, tx]);
  const addDeposit = (amount, user) => setDeposits((prev) => [...prev, { user, amount, time: new Date().toISOString() }]);

  return (
    <PotContext.Provider value={{
      currentPot,
      setCurrentPot,
      transactions,
      addTransaction,
      voteStatus,
      setVoteStatus,
      deposits,
      addDeposit
    }}>
      {children}
    </PotContext.Provider>
  );
};
