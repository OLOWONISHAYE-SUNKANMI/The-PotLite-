
// PotDashboard.jsx - Display details of a specific Pot

import React from 'react';
import theme from '../styles/theme';

const PotDashboard = ({ pot }) => {
  return (
    <div style={{ backgroundColor: theme.colors.secondaryBackground, color: theme.colors.secondaryText, padding: '2rem', borderRadius: '8px' }}>
      <h2 style={{ color: theme.colors.primaryText }}>{pot.name}</h2>
      <p><strong>Goal:</strong> {pot.goalAmount} dummy coins</p>
      <p><strong>Payout Structure:</strong> {pot.payoutMethod}</p>
      <p><strong>Withdrawal Method:</strong> {pot.withdrawalMethod}</p>
      <p><strong>Members:</strong> {pot.members.join(', ')}</p>
      <p><strong>Balance:</strong> {pot.balance} dummy coins</p>
    </div>
  );
};

export default PotDashboard;
