
// TimedRelease.jsx - Countdown for time-locked withdrawals

import React, { useEffect, useState } from 'react';
import theme from '../styles/theme';

const TimedRelease = ({ deadline, onUnlock }) => {
  const [timeLeft, setTimeLeft] = useState(Math.max(0, deadline - Date.now()));

  useEffect(() => {
    const timer = setInterval(() => {
      const diff = Math.max(0, deadline - Date.now());
      setTimeLeft(diff);
      if (diff <= 0) {
        clearInterval(timer);
        onUnlock();
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [deadline, onUnlock]);

  const formatTime = (ms) => {
    const totalSec = Math.floor(ms / 1000);
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return `${min}m ${sec}s`;
  };

  return (
    <div style={{ marginTop: '1rem', backgroundColor: theme.colors.primaryBackground, padding: '1rem', borderRadius: '8px', color: theme.colors.secondaryText }}>
      <h3>Time-Locked Withdrawal</h3>
      {timeLeft > 0 ? (
        <p>Available in: <strong>{formatTime(timeLeft)}</strong></p>
      ) : (
        <button onClick={onUnlock} style={{
          background: `linear-gradient(to right, ${theme.colors.buttonGradientStart}, ${theme.colors.buttonGradientEnd})`,
          color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '4px'
        }}>
          Withdraw Now
        </button>
      )}
    </div>
  );
};

export default TimedRelease;
