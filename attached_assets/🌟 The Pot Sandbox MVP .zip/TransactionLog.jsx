
// TransactionLog.jsx - Displays transaction history in sandbox

import React from 'react';
import theme from '../styles/theme';

const TransactionLog = ({ logs }) => {
  return (
    <div style={{ marginTop: '1rem', backgroundColor: theme.colors.secondaryBackground, padding: '1rem', borderRadius: '8px' }}>
      <h3 style={{ color: theme.colors.primaryText }}>Transaction Log</h3>
      <ul>
        {logs.map((log, index) => (
          <li key={index} style={{ color: log.type === 'error' ? theme.colors.error : theme.colors.success }}>
            [{log.type.toUpperCase()}] {log.message}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TransactionLog;
