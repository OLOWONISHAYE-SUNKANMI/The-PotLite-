
// VotingUI.jsx - Simulate the voting process for democratic withdrawals

import React, { useState } from 'react';
import theme from '../styles/theme';

const VotingUI = ({ request, members }) => {
  const [votes, setVotes] = useState({});
  const [result, setResult] = useState('');

  const castVote = (member, decision) => {
    const updatedVotes = { ...votes, [member]: decision };
    setVotes(updatedVotes);

    if (Object.keys(updatedVotes).length === members.length) {
      const approvals = Object.values(updatedVotes).filter(v => v === 'yes').length;
      setResult(approvals > members.length / 2 ? "Approved" : "Rejected");
    }
  };

  return (
    <div style={{ padding: '1rem', backgroundColor: theme.colors.primaryBackground, color: theme.colors.secondaryText }}>
      <h3>Withdrawal Request</h3>
      <p>{request.user} wants to withdraw {request.amount} dummy coins</p>
      {members.map(member => (
        <div key={member}>
          {member}: 
          <button onClick={() => castVote(member, 'yes')}>Yes</button>
          <button onClick={() => castVote(member, 'no')}>No</button>
        </div>
      ))}
      {result && <p>Final Result: {result}</p>}
    </div>
  );
};

export default VotingUI;
