
// theme.js - Brand color palette for The Pot

const theme = {
  colors: {
    primaryBackground: "#5B1FA6",    // Royal Purple
    secondaryBackground: "#3D0F6C",  // Deep Plum
    primaryText: "#FFD94A",          // Golden Yellow
    secondaryText: "#FAF8FF",        // Light Lavender
    accent: "#F4B831",               // Coin Gold
    success: "#B8E986",              // Lime Green
    error: "#FF6E6E",                // Coral Red
    buttonGradientStart: "#8E2DE2",  // Pink Purple
    buttonGradientEnd: "#4A00E0",    // Deep Violet
  },
  font: {
    family: "'Poppins', sans-serif",
    sizeBase: "16px",
    weightRegular: 400,
    weightBold: 700,
  }
};

export default theme;
